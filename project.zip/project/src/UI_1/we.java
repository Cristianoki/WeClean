package UI_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.ImageIcon;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

public class we extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					we frame = new we();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public we() {
		setResizable(false);
		setAutoRequestFocus(false);
		getContentPane().setBackground(Color.WHITE);
		setBackground(Color.WHITE);
		setTitle("WeClean");
		getContentPane().setFont(new Font("Arial", Font.PLAIN, 12));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 104, 450, 300);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("./source/ss.jpg"));
		btnNewButton.setBounds(363, 171, 30, 30);
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		textField = new JTextField();
		textField.setFont(new Font("Calibri", Font.PLAIN, 13));
		textField.setBounds(37, 172, 322, 28);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("΢���ź�", Font.PLAIN, 11));
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setBackground(new Color(255, 255, 255));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"English", "Duestch", "\u4E2D\u6587"}));
		comboBox.setBounds(359, 10, 65, 20);
		getContentPane().add(comboBox);

		JTextPane txtpnSearchIn = new JTextPane();
		txtpnSearchIn.setForeground(new Color(0, 0, 204));
		txtpnSearchIn.setBackground(Color.WHITE);
		txtpnSearchIn.setEnabled(false);
		txtpnSearchIn.setFont(new Font("Arial", Font.PLAIN, 11));
		txtpnSearchIn.setEditable(false);
		txtpnSearchIn.setText("search in:");
		txtpnSearchIn.setBounds(34, 148, 54, 20);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("brand");
		chckbxNewCheckBox_1.setForeground(new Color(0, 51, 102));
		chckbxNewCheckBox_1.setBackground(Color.WHITE);
		chckbxNewCheckBox_1.setBounds(95, 150, 54, 16);
		chckbxNewCheckBox_1.setFont(new Font("Arial", Font.PLAIN, 11));
		
		JCheckBox chckbxNewCheckBox_3 = new JCheckBox("name");
		chckbxNewCheckBox_3.setForeground(new Color(0, 51, 102));
		chckbxNewCheckBox_3.setBackground(Color.WHITE);
		chckbxNewCheckBox_3.setBounds(153, 150, 51, 16);
		chckbxNewCheckBox_3.setFont(new Font("Arial", Font.PLAIN, 11));
		
		JCheckBox chckbxNewCheckBox_2 = new JCheckBox("function");
		chckbxNewCheckBox_2.setForeground(new Color(0, 51, 102));
		chckbxNewCheckBox_2.setBackground(Color.WHITE);
		chckbxNewCheckBox_2.setBounds(208, 150, 65, 16);
		chckbxNewCheckBox_2.setFont(new Font("Arial", Font.PLAIN, 11));
		
		JCheckBox chckbxFavourite = new JCheckBox("favourite");
		chckbxFavourite.setForeground(new Color(0, 51, 102));
		chckbxFavourite.setBackground(Color.WHITE);
		chckbxFavourite.setBounds(278, 150, 71, 16);
		chckbxFavourite.setFont(new Font("Arial", Font.PLAIN, 11));
		
		getContentPane().setLayout(null);
		getContentPane().add(btnNewButton);
		getContentPane().add(chckbxNewCheckBox_1);
		getContentPane().add(chckbxNewCheckBox_2);
		getContentPane().add(chckbxNewCheckBox_3);
		getContentPane().add(chckbxFavourite);
		getContentPane().add(txtpnSearchIn);
		
		JButton btnNewButton_1 = new JButton("instruction");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				File file=new File("./source/instructions for WeClean.txt"); 
				try {
					java.awt.Desktop.getDesktop().open(file);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		btnNewButton_1.setForeground(new Color(169, 169, 169));
		btnNewButton_1.setMargin(new Insets(20, 1, 20, 1));
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 9));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(153, 238, 52, 16);
		getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("about us");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				File file=new File("./source/information of producers.txt"); 
				try {
					java.awt.Desktop.getDesktop().open(file);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setForeground(new Color(169, 169, 169));
		btnNewButton_2.setMargin(new Insets(20, 1, 20, 1));
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 9));
		btnNewButton_2.setBounds(215, 238, 45, 16);
		getContentPane().add(btnNewButton_2);
		
		JLabel lblPleaseInputThe = new JLabel("");
		lblPleaseInputThe.setIcon(new ImageIcon("./source/we.jpg"));
		lblPleaseInputThe.setBounds(-19, 7, 437, 214);
		getContentPane().add(lblPleaseInputThe);
		
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("./source/kb.jpg"));
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBackground(UIManager.getColor("FormattedTextField.selectionBackground"));
		label_1.setBounds(34, 170, 362, 33);
		getContentPane().add(label_1);

		
	}
}
